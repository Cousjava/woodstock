({
		invalidMessage: "* Wprowadzona wartość nie jest poprawna.",
		missingMessage: "* Ta wartość jest wymagana.",
		rangeMessage: "* Ta wartość jest spoza zakresu."
})
