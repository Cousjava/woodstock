({
		invalidMessage: "* 非法的输入值。",
		missingMessage: "* 此值是必须的。",
		rangeMessage: "* 输入数据超出值域。"
})
