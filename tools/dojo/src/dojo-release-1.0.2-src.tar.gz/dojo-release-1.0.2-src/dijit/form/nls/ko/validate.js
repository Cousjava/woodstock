({
		invalidMessage: "* 입력한 값이 유효하지 않습니다. ",
		missingMessage: "* 이 값은 필수입니다. ",
		rangeMessage: "* 이 값은 범위를 벗어납니다. "
})
