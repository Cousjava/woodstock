({
		invalidMessage: "* O valor digitado não é válido.",
		missingMessage: "* Esse valor é necessário.",
		rangeMessage: "* Esse valor está fora do intervalo."
})
