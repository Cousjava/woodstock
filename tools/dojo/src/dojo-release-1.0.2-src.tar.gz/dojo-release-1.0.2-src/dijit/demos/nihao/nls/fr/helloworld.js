({
	"localeSelect": "Lieu :",
	"contentStr": "Bonjour globalisation de Dojo! Aujourd'hui est ${0}.",
	"dateSelect": "Choisir une date :",
	"dateStr": "${0} secondes à aller dès maintenant."
})