({
	"localeSelect":"Locale:",
	"contentStr":"Hello Dojo Globalization! Today is ${0}.",
	"dateSelect": "Select a date:",
	"dateStr": "${0} seconds to go from now."
})