({
	buttonOk: "OK",
	buttonCancel: "Storno",
	buttonSave: "Uložit"
})
