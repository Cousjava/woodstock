({
	buttonOk: "OK",
	buttonCancel: "Mégse",
	buttonSave: "Mentés"
})
