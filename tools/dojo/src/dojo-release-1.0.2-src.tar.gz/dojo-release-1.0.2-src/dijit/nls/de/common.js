({
	buttonOk: "OK",
	buttonCancel: "Abbrechen",
	buttonSave: "Speichern"
})
