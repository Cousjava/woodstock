({
	buttonOk: "OK",
	buttonCancel: "Annulla",
	buttonSave: "Salva"
})
