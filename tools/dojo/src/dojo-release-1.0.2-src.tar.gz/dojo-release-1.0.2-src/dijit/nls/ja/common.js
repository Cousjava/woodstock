({
	buttonOk: "OK",
	buttonCancel: "キャンセル",
	buttonSave: "保存"
})
