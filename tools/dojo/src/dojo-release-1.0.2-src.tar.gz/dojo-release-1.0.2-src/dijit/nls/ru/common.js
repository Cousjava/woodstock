({
	buttonOk: "ОК",
	buttonCancel: "Отмена",
	buttonSave: "Сохранить"
})
