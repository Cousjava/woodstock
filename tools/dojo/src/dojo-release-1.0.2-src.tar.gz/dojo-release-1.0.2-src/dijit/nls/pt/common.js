({
	buttonOk: "OK",
	buttonCancel: "Cancelar ",
	buttonSave: "Salvar"
})
