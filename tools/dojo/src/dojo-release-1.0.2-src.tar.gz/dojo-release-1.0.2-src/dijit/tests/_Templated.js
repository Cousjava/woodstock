dojo.provide("dijit.tests._Templated");

if(dojo.isBrowser){
	doh.registerUrl("dijit.tests._Templated", dojo.moduleUrl("dijit", "tests/_Templated.html"));
}
