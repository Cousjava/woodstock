dojo.provide("dijit.tests.widgetsInTemplate");

if(dojo.isBrowser){
	doh.registerUrl("dijit.tests.widgetsInTemplate", dojo.moduleUrl("dijit", "tests/widgetsInTemplate.html"));
}
