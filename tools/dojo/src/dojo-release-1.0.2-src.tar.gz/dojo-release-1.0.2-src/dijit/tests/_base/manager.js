dojo.provide("dijit.tests._base.manager");

if(dojo.isBrowser){
	doh.registerUrl("dijit.tests._base.manager", dojo.moduleUrl("dijit", "tests/_base/manager.html"));
}
