dojo.provide("dijit.tests._base.wai");

if(dojo.isBrowser){
	doh.registerUrl("dijit.tests._base.wai", dojo.moduleUrl("dijit", "tests/_base/wai.html"));
}
