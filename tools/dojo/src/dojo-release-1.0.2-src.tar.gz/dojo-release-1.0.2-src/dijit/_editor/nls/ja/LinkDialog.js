({
	title: "URL にリンク",
	url: "URL:",
	text: "テキスト:",
	set: "設定",
	urlInvalidMessage: "無効な URL です。完全な URL (例えば、http://www.dojotoolkit.org) を入力してください。"	
})
