({
	title: "Adres URL odsyłacza",
	url: "Adres URL:",
	text: "Tekst:",
	set: "Ustaw",
	urlInvalidMessage: "Nieprawidłowy adres URL. Wprowadź pełny adres URL, na przykład http://www.dojotoolkit.org."	
})
