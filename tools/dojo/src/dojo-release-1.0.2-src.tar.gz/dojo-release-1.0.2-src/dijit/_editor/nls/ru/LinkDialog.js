({
	title: "URL ссылки",
	url: "URL:",
	text: "Текст:",
	set: "Задать",
	urlInvalidMessage: "Недопустимый адрес URL.  Укажите полный URL, например: 'http://www.dojotoolkit.org'"	
})
