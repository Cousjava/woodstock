({
	title: "URL di collegamento",
	url: "URL:",
	text: "Testo:",
	set: "Imposta",
	urlInvalidMessage: "URL non valido.  Immettere un URL completo come nel seguente esempio: 'http://www.dojotoolkit.org'"	
})
