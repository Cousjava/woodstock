({
	title: "Link-URL",
	url: "URL:",
	text: "Text:",
	set: "Festlegen",
	urlInvalidMessage: "Ungültiger URL. Geben Sie einen vollständigen URL ein. Beispiel: 'http://www.dojotoolkit.org'"	
})
