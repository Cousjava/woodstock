({
	title: "Adresa URL odkazu",
	url: "Adresa URL:",
	text: "Text:",
	set: "Nastavit",
	urlInvalidMessage: "Neplatná adresa URL. Zadejte úplnou adresu URL ve tvaru 'http://www.dojotoolkit.org'"	
})
