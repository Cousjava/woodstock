({
	title: "链接 URL",
	url: "URL：",
	text: "文本：",
	set: "设定",
	urlInvalidMessage: "URL 无效。请输入完整的 URL，如“http://www.dojotoolkit.org”"	
})
