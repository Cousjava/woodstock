({
	title: "URL du lien",
	url: "URL :",
	text: "Texte :",
	set: "Définir",
	urlInvalidMessage: "Adresse URL non valide. Entrez une adresse URL complète de type 'http://www.dojotoolkit.org'"	
})
