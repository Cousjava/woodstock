({
	title: "Hivatkozás URL címe",
	url: "URL:",
	text: "Szöveg:",
	set: "Beállítás",
	urlInvalidMessage: "Érvénytelen URL cím. Adjon meg teljes URL címet, például: 'http://www.dojotoolkit.org'"	
})
