({
	title: "鏈結 URL",
	url: "URL：",
	text: "文字：",
	set: "設定",
	urlInvalidMessage: "URL 無效。請輸入完整的 URL，例如 'http://www.dojotoolkit.org'"	
})
