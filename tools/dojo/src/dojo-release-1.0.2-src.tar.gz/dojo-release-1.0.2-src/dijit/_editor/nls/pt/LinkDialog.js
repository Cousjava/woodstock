({
	title: "Vincular URL",
	url: "URL:",
	text: "Texto:\n",
	set: "Definir\n",
	urlInvalidMessage: "URL inválida. Digite uma URL completa, como 'http://www.dojotoolkit.org'"	
})
