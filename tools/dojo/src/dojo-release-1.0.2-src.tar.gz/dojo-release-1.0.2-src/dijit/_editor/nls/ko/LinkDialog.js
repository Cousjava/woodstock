({
	title: "URL 링크",
	url: "URL:",
	text: "텍스트:",
	set: "설정",
	urlInvalidMessage: "유효하지 않은 URL입니다. 'http://www.dojotoolkit.org'와 같이 전체 URL을 입력하십시오. "	
})
