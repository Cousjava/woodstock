#!/bin/sh

java -jar ../shrinksafe/custom_rhino.jar build.js "$@"
