dojo.provide("dojox.math");
dojo.require("dojox.math._base");
