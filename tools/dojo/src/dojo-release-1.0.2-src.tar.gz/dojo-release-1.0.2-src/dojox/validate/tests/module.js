dojo.provide("dojox.validate.tests.module");

try{
	dojo.require("dojox.validate.tests.creditcard");
	dojo.require("dojox.validate.tests.validate"); 

}catch(e){
	doh.debug(e);
	console.debug(e); 
}
